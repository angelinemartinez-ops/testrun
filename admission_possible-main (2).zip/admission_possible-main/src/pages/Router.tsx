import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Circle } from '../components/Circle';
import { QUESTIONS } from '../data/questions';
import { trackEvent } from '../data/analytics';
import { computePlan } from '../data/plan';
import { useHydrated } from '../hooks/useHydrated';
import { clearDraft, loadDraft, loadIntake, saveDraft, saveIntake } from '../data/storage';
import type { Answers, Intake } from '../types';
import '../styles/application.css';

// The 7-step intake. Computes the plan and hands off via storage.
export default function Router() {
  const navigate = useNavigate();
  // This route is prerendered in Node, where there is no storage, so the seed
  // is *derived* and only applied once hydrated — the first client paint has to
  // agree with the served HTML (#45). Anything the student then does overlays
  // it via `edits`.
  const hydrated = useHydrated();
  const [edits, setEdits] = useState<{ step: number; answers: Answers } | null>(null);

  // The per-tab draft wins, so pull-to-refresh or a gesture-back on steps 2-7
  // doesn't discard answers; otherwise fall back to a completed intake so
  // re-entry isn't seven questions from memory.
  const draft = useMemo(() => (hydrated ? loadDraft() : null), [hydrated]);
  const prior: Intake | null = useMemo(() => (hydrated ? loadIntake() : null), [hydrated]);
  const seed = useMemo(
    () =>
      draft
        ? // Clamp: a stale draft from a shorter/longer question set must not index out.
          { step: Math.min(Math.max(draft.step, 0), QUESTIONS.length - 1), answers: draft.answers }
        : prior
          ? { step: 0, answers: prior.answers }
          : null,
    [draft, prior],
  );

  const step = edits?.step ?? seed?.step ?? 0;
  // Memoised: a fresh {} each render would re-run the draft-save effect below
  // on every render rather than on every change.
  const answers: Answers = useMemo(() => edits?.answers ?? seed?.answers ?? {}, [edits, seed]);
  // Only announce the reseed when it actually happened — an in-progress draft
  // takes precedence, and there is nothing to say on a first run.
  const resumed = hydrated && !draft && !!prior;
  const [saveError, setSaveError] = useState(false);
  const questionRef = useRef<HTMLHeadingElement>(null);
  const firstRender = useRef(true);

  const setStep = (next: number) => setEdits({ step: next, answers });
  const setAnswers = (next: Answers) => setEdits({ step, answers: next });

  // Persist progress on every change, so there is no window where an answer is
  // only in React state.
  useEffect(() => {
    if (!hydrated) return;
    saveDraft(step, answers);
  }, [hydrated, step, answers]);

  // One event per step reached, so the funnel's drop-off point is visible.
  useEffect(() => {
    trackEvent({ name: 'intake_step', step: step + 1 });
  }, [step]);

  // Move focus to the new question on each step. The question, hint and options
  // re-render in place with no live region, so the change was silent to a
  // screen reader — and worse, the focused Next button becomes disabled when
  // the unanswered question renders, which drops focus to <body> outright.
  // Focusing the heading announces the question and resets reading position;
  // the adjacent "n / 7" meta line supplies the progress context.
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    questionRef.current?.focus();
  }, [step]);

  const total = QUESTIONS.length;
  const q = QUESTIONS[step];
  const sel = answers[q.key];
  const isLast = step === total - 1;
  const canNext = q.multi ? Array.isArray(sel) && sel.length > 0 : !!sel;

  const isSelected = (opt: string) => (q.multi ? Array.isArray(sel) && sel.indexOf(opt) >= 0 : sel === opt);

  const select = (opt: string) => {
    setAnswers(
      (() => {
        const a: Answers = { ...answers };
        if (q.multi) {
          const cur = Array.isArray(a[q.key]) ? [...(a[q.key] as string[])] : [];
          const i = cur.indexOf(opt);
          if (i >= 0) cur.splice(i, 1);
          else cur.push(opt);
          a[q.key] = cur;
        } else {
          a[q.key] = opt;
        }
        return a;
      })(),
    );
  };

  const next = () => {
    if (!canNext) return;
    if (step < total - 1) {
      setStep(step + 1);
      window.scrollTo({ top: 0 });
    } else {
      const plan = computePlan(answers);
      // Redoing the intake used to discard the track the student had switched
      // to on the plan page. Carry it forward when they didn't change their
      // answer to the track question.
      const keepOverride = prior?.trackOverride && prior.answers.track === answers.track;
      const next: Intake = keepOverride ? { answers, plan, trackOverride: prior.trackOverride } : { answers, plan };
      if (!saveIntake(next)) {
        setSaveError(true);
        return;
      }
      clearDraft();
      trackEvent({ name: 'plan_generated', pathway: plan.pathway });
      // `replace`, so Back from the freshly generated plan doesn't remount a
      // blank question 1 — which reads as though the plan was deleted.
      navigate('/plan', { replace: true });
    }
  };

  const back = () => {
    if (step > 0) {
      setStep(step - 1);
      window.scrollTo({ top: 0 });
    } else {
      // Leaving the intake from step 1 abandons it; don't resurrect the draft.
      clearDraft();
      navigate('/');
    }
  };

  return (
    <main className="ov-intake">
      <div
        className="ov-progress"
        role="progressbar"
        aria-label="Intake progress"
        aria-valuemin={1}
        aria-valuemax={total}
        aria-valuenow={step + 1}
      >
        {QUESTIONS.map((_, i) => (
          <div key={i} className={`ov-seg${i <= step ? ' is-reached' : ''}`} />
        ))}
      </div>
      <div className="ov-router">
        <h1 className="ov-router__eyebrow">Your 2-minute intake</h1>
        <div className="ov-router__meta">
          {step + 1} / {total}
          {q.multi && <span className="ov-router__hint">Select all that apply</span>}
        </div>
        {resumed && step === 0 && (
          <p className="ov-router__resume">
            You already have a plan — your answers are filled in below. Change anything and we'll rebuild it, or{' '}
            <Link to="/plan">go back to your plan</Link>.
          </p>
        )}
        <h2 className="ov-router__q" id="router-question" key={q.key} ref={questionRef} tabIndex={-1}>
          {q.q}
        </h2>
        <div className="ov-ans__list" key={`answers-${q.key}`} role="group" aria-labelledby="router-question">
          {q.options.map((opt) => {
            const on = isSelected(opt);
            return (
              <button type="button" className="ov-ans" key={opt} onClick={() => select(opt)} aria-pressed={on}>
                <span className={'ov-ans__mark' + (on ? ' is-on' : '')} aria-hidden="true" />
                <span className={'ov-ans__label' + (on ? ' is-on' : '')}>{opt}</span>
              </button>
            );
          })}
        </div>
        {saveError && (
          <p className="ov-router__error" role="alert">
            We couldn't save your plan — your browser is blocking site storage (this can happen in private browsing).
            Allow storage for this site, or leave private mode, and press the button again.
          </p>
        )}
        <div className="ov-router__foot">
          <button className="ov-back" onClick={back}>
            {step === 0 ? 'Cancel' : 'Back'}
          </button>
          {isLast ? (
            <Circle size="router" onClick={next} disabled={!canNext} style={{ opacity: canNext ? 1 : 0.35 }}>
              See my plan
            </Circle>
          ) : (
            <button className="ov-next" onClick={next} disabled={!canNext} style={{ opacity: canNext ? 1 : 0.35 }}>
              Next
              <svg className="ov-next__arrow" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M3 12h17M13 5l7 7-7 7" stroke="currentColor" strokeWidth="1.5" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </main>
  );
}
