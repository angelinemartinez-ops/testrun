# (Ad)mission Possible

> The college application, demystified — and free, built for the first in their family.

A landing experience plus an interactive intake that turns a few questions
into a concrete plan — a recommended application pathway, a balanced starter
college list, and a study track — followed by a student dashboard.

---

## Table of contents

- [Overview](#overview)
- [Tech stack](#tech-stack)
- [Getting started](#getting-started)
- [Available scripts](#available-scripts)
- [Project structure](#project-structure)
- [Routes](#routes)
- [The opening intro](#the-opening-intro)
- [About & the founding team](#about--the-founding-team)
- [The intake flow](#the-intake-flow)
- [Design system](#design-system)
- [Accessibility](#accessibility)
- [Testing & CI](#testing--ci)
- [Deployment](#deployment)

---

## Overview

(Ad)mission Possible is a React single-page app that walks a student from a
bold landing page through a 7-question intake and into a personalized plan
and dashboard. The goal is to make the application process legible for
students who are navigating it without a map.

---

## Tech stack

| Concern     | Choice                                                       |
| ----------- | ------------------------------------------------------------ |
| UI          | **React 19** + **TypeScript** (strict)                       |
| Build / dev | **Vite 8**                                                   |
| Routing     | **React Router 8** (client-side)                             |
| Styling     | Hand-authored CSS (`global.css` + `editorial.css` + a few page-scoped sheets) |
| Tests       | **Vitest 4** + **Testing Library** (jsdom)                   |
| Hosting     | Prerendered static site on Vercel (client-routed after load) |

---

## Getting started

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type-check (tsc -b) + production build to dist/
npm run preview    # serve the production build
```

The project targets **Node 24** (`.nvmrc` / `package.json` `engines`) — match
that locally if you build it yourself; CI and Vercel both use it.

---

## Available scripts

| Script                  | What it does                              |
| ------------------------ | ------------------------------------------ |
| `npm run dev`             | Start the Vite dev server with HMR        |
| `npm run build`           | Type-check, build client + SSR bundles, then prerender every route to `dist/` |
| `npm run preview`         | Serve the production build locally        |
| `npm run typecheck`       | `tsc -b --noEmit`                         |
| `npm run lint`            | ESLint (flat config, TS + react-hooks)    |
| `npm run format`          | Prettier write (`format:check` to verify) |
| `npm test`                | Vitest + Testing Library (jsdom)          |
| `npm run test:coverage`   | Vitest with coverage                      |

---

## Project structure

```
public/
  art/                    # generative-art assets (flower video/poster loops)
  brand/                  # logo, wordmark cap
  team/                   # founding-team photos + SVG placeholder portraits
  fonts/                  # self-hosted Beausite / Geist / Geist Mono / Inter woff2s
src/
  main.tsx                # entry; mounts <App/> in <BrowserRouter> + ErrorBoundary
  entry-server.tsx        # SSR entry used only at build time for prerendering
  App.tsx                 # routes, all nested under the Chrome layout
  types.ts                # shared domain types
  data/                   # nav, questions, plan (computePlan), storage,
                          #   team content, routes manifest, analytics, titles
  hooks/
    useReveal.ts           # scroll reveal/slash (re-scanned per route)
    useScrollHideHeader.ts
    useHydrated.ts          # guards storage reads until after hydration
    useOpeningIntro.ts      # controls the one-time homepage opening animation
  components/
    Chrome, Header, Menu, Footer, Crumbs, Icon, Circle, Slash, Wordmark,
    ErrorBoundary, OpeningIntro, AdmissionArt, DecorativeVideo,
    EditorialHero, NoPlan, TeamCard
  pages/                  # Home, About, How, Offer, Join, Privacy, Router,
                          #   Plan, Dashboard, TeamMember, NotFound
  styles/                 # global.css (design tokens + most components),
                          #   editorial.css (Beausite @font-face + editorial
                          #   layouts), plus a few page-scoped sheets
```

> Files are grouped by role (data / hooks / components / pages / styles).
> Imports rely on these locations, so prefer extending a folder over moving
> files across folders.

---

## Routes

| Path                                | Page                               |
| ------------------------------------ | ----------------------------------- |
| `/`                                    | Home                                 |
| `/about`                                | About us (founding-team directory)   |
| `/how`                                   | How admissions works                 |
| `/offer`                                  | What we offer                        |
| `/join`                                    | Join                                 |
| `/privacy`                                  | Privacy                              |
| `/team/:slug`                                 | Founding-team profile                |
| `/router` → `/plan` → `/dashboard`               | The intake flow            |
| `*`                                                | Not found                            |

This list is the single source of truth and is enforced by tests: `App.tsx`'s
`<Route>` list, `src/data/routes.ts` (the prerender manifest), and
`Routes.test.tsx` all have to agree, including an explicit test that earlier,
now-removed product pages (`/writing-course`, `/list-builder`, `/pathways`,
`/coaching`) correctly 404 rather than silently reappearing.

---

## The opening intro

The Home page opens with a brief, full-screen title animation
(`src/components/OpeningIntro.tsx`, driven by `useOpeningIntro.ts`): the
headline *"Impossible becomes Possible"* animates into the header's real
wordmark. It plays once per fresh visit to `/` — not on internal
navigation — lasts about 4 seconds, is skippable, and is disabled entirely
under `prefers-reduced-motion`, on a paused-motion flag in `sessionStorage`,
or if the page loads with a URL hash (e.g. a deep link into a section).

Elsewhere on the site, `AdmissionArt.tsx` renders the generative SVG/video
"art" panels (flower loops layered behind window shapes) used as section
dividers and hero backgrounds; `DecorativeVideo.tsx` handles the underlying
`<video>` playback (autoplay, muted, reduced-motion-aware).

---

## About & the founding team

The About page (`/about`) opens with a "Who we are" statement, then a
**Founding team** directory: four cards (`TeamCard.tsx`) — Jose, Haolin,
Angeline, and Rehan — each an expand **button** (an `aria-expanded`
disclosure). Clicking one toggles a shared inline intro panel below the grid
with the member's full name, journey line, bio, a bold belief statement, and
colored role chips, plus a "Read my full story →" link to `/team/:slug`.
Content lives in `src/data/team.ts` (a single source of truth shared by the
directory and the profile pages), so a card and its page never drift apart.

`/team/:slug` renders `TeamMember.tsx` — a "My story" profile: a heading, a
three-column row (journey path / narrative / a bold belief statement with a
muted sub-paragraph), a wide hero image, a row of pastel skill pills, and a
"Back to About us" pill in the top-left.

**Swapping in real photos** — drop files into `public/team/` and update the
`photo` (card) and `storyPhoto` (wide hero) paths in `team.ts`. The `*.svg`
files are brand-palette placeholders; real photos override them.

---

## The intake flow

`Get my plan` goes to `/router`, a 7-question intake. On the last step the
answers and the computed plan are saved to `localStorage` (the primary store,
so a plan survives a closed tab and a return visit tomorrow; `sessionStorage`
is used only as a read/write fallback when `localStorage` is unavailable,
e.g. Safari private mode) and the user is sent to `/plan`; the plan's track
toggle persists and is reflected on `/dashboard`. Visiting `/plan` or
`/dashboard` without a stored intake shows `NoPlan.tsx` — an explanatory page
("We couldn't find your plan") with a link back into the intake, rather than
silently redirecting. `computePlan()` maps answers to a pathway, a balanced
reach/target/likely list, and a track.

---

## Design system

- **Type** — Beausite (`--display`, `--sans` — headings and most UI text) +
  Geist Mono (`--mono` — labels, kickers, mono accents) + Inter (fallback,
  and used directly in a few places). All four families are self-hosted from
  `public/fonts/` via `@font-face` rules split across `global.css` and
  `editorial.css`; there are no Google Fonts requests anywhere in the site.
- **Palette**
  | Token             | Value     | Use                          |
  | ------------------- | --------- | ----------------------------- |
  | `--bg`                | `#FFFFFF` | page background               |
  | `--ink`                 | `#111111` | text                           |
  | `--muted`                 | `#555555` | secondary text                 |
  | `--accent`                  | `#B388EB` | lavender accent                |
  | `--accent-soft`               | `#F7AEF8` | plum accent                     |
  | `--card`                        | `#FFFFFF` | surfaces                        |
  | `--hairline`                      | `#C9C9C9` | rules / borders                  |
  | `--menu-bg`                        | `#111111` | full-screen menu overlay          |
  | `--pink` / `--plum` / `--lavender` / `--blue` / `--sky` | `#FDC5F5` / `#F7AEF8` / `#B388EB` / `#8093F1` / `#72DDF7` | pastel palette used across `AdmissionArt` and chips |
- **Motion** — scroll-triggered reveals and rotating hairline "slashes",
  re-scanned on each route change (`IntersectionObserver` + scroll/timeout
  fallback), plus the opening intro above. All respect
  `prefers-reduced-motion`.
- **Icons** — `Icon.tsx` renders every icon name as an inline freehand SVG
  (no PNG icon map). The header's menu button and the wordmark's graduation
  cap are the only raster images in the chrome, served from `public/brand/`.

---

## Accessibility

- Skip link, `main` landmark, and visible focus styles.
- The menu dialog has dialog semantics and moves focus on open.
- Router options are keyboard-operable.
- All motion honours `prefers-reduced-motion`; decorative art and video use
  empty `alt` text / `aria-hidden`.

---

## Testing & CI

Tests live next to the code they cover (`*.test.ts[x]`) and include
`computePlan` branch coverage, storage round-trips, component unit tests, a
fonts/CSP/caching config test (`src/styles/fonts.test.ts`), and an
end-to-end intake-flow test (router → plan → dashboard). CI
(`.github/workflows/ci.yml`) runs a dependency audit, typecheck, lint, format
check, tests, and build on every push and PR to `main`. GitHub Actions are
pinned to full commit SHAs, kept current by Dependabot.

---

## Deployment

Every route is **prerendered to its own HTML file** at build time, so
crawlers and link-preview bots get real content instead of an empty root div,
and each page carries its own title, description and canonical. `npm run
build` does three things: the client bundle, an SSR bundle from
`src/entry-server.tsx`, and `scripts/prerender.mjs`, which writes
`dist/<route>/index.html` for every entry in `src/data/routes.ts` plus a
`404.html`.

Two consequences worth knowing:

- **There is no SPA catch-all rewrite.** Unknown paths get `404.html` with a
  real 404 status, not a 200'd empty shell. **A new route must be added to
  `src/data/routes.ts` (and `public/sitemap.xml`) or it will 404 in
  production** — a test fails if the route manifest drifts from `App.tsx`.
- **Never read storage during render.** The prerender runs in Node with no
  `localStorage`, so a component that reads stored intake inline renders
  differently on a returning student's first paint, and React discards the
  prerendered tree. Go through `useHydrated()` (see `src/hooks/`); a test
  hydrates every route and fails on any mismatch.

This project is already wired for **Vercel**: `vercel.json` sets response
(including CSP) headers and cache rules, and `api/join.ts` is a Vercel
Function. To deploy: push to GitHub, import the repo in Vercel, and set the
environment variables below — the build command and output directory are
inferred from `package.json`/`vercel.json`.

### Security headers

`vercel.json` sets a strict Content-Security-Policy. The default
`connect-src 'self'` allows same-origin requests only.

**Wiring up the Join form:** Join POSTs to the same-origin `/api/join`
Vercel Function (`api/join.ts`) by default, which `connect-src 'self'`
already allows — no CSP change needed. If you override
`VITE_JOIN_ENDPOINT` (see `src/pages/Join.tsx`) with a **cross-origin**
backend such as Formspree or Getform, that `fetch` is a `connect-src` and
will be **blocked** by the CSP until you add the endpoint's origin. Update
the `connect-src` slot in `vercel.json`:

```diff
- "connect-src 'self'; ...
+ "connect-src 'self' https://your-form-backend.example; ...
```

`vercel.json` is strict JSON and can't hold comments, so this is the
canonical note for that edit.

### Environment variables

Copy `.env.example` to `.env.local` for local development, and set the same
keys in the Vercel project settings for deploys. See that file for the full
list; the ones that matter for Join are:

| Variable             | Where  | Purpose                                                                                                                                        |
| -------------------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| `RESEND_API_KEY`     | server | Required for `/api/join` to deliver mail. Unset ⇒ the endpoint returns 503 and the form shows a copyable fallback instead of claiming success. |
| `JOIN_NOTIFY_EMAIL`  | server | The inbox that receives submissions.                                                                                                           |
| `JOIN_FROM_EMAIL`    | server | Optional sender, on a Resend-verified domain.                                                                                                  |
| `VITE_CONTACT_EMAIL` | client | A public address to show as a manual fallback. **Leave unset until you verifiably control the mailbox** — see below.                           |
| `VITE_JOIN_ENDPOINT` | client | Override the POST target. Defaults to `/api/join`.                                                                                             |

> **Contact address:** `VITE_CONTACT_EMAIL` ships in the client bundle and is
> shown to students. Only set this to a mailbox whose domain ownership and
> inbox delivery you have verified end to end — an address on someone else's
> domain sends student PII to that organization. When it is unset, the form
> shows the composed message for copying and names no address at all.

Without `RESEND_API_KEY`/`JOIN_NOTIFY_EMAIL` set, the "Join us" form doesn't
break — `/api/join` returns 503 and the form gracefully falls back to a
"copy your message" flow instead of claiming the submission succeeded.
